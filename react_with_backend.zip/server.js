
/* File: server.js */

const express = require('express');
const cors = require('cors');

const app = express();
const port = 5000;

app.use(cors());

// Dummy data for quizzes and leaderboard
const quizzes = [
  { id: 1, title: "AI Ethics", questions: ["What is AI?", "Why is ethics important in AI?"] },
  { id: 2, title: "Environmental Ethics", questions: ["What is climate change?", "How can we reduce waste?"] }
];

const leaderboard = [
  { id: 1, name: "Alice", points: 150 },
  { id: 2, name: "Bob", points: 120 },
  { id: 3, name: "Charlie", points: 100 }
];

// Routes
app.get('/', (req, res) => {
  res.send('Welcome to the Ethics Quest API!');
});

app.get('/api/quizzes', (req, res) => {
  res.json(quizzes);
});

app.get('/api/leaderboard', (req, res) => {
  res.json(leaderboard);
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
