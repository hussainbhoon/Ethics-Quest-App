
/* File: src/components/Section.js */

import React from 'react';

function Section({ title, items }) {
  return (
    <section className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {items.map((item, index) => (
          <div key={index} className="bg-gray-200 p-4 rounded-lg">
            <img src={item.image} alt={item.title} className="mb-4" width="300" height="200" />
            <h3 className="font-bold">{item.title}</h3>
            <p>{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Section;
